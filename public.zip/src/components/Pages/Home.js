import Videos from '../Videos'

const Home = () => {
  return (
    <>
      <Videos />
    </>
  )
}

export default Home
